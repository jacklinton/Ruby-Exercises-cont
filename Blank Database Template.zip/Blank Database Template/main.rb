require "sinatra"
require "sinatra/activerecord"
require "./models"

set :database, "/////"

get "/" do 

end